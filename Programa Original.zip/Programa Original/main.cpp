////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
   APP de Gastos personales (MY FINANCE) Ver 3.0.1
   Hecho por: Juan Esteban Villegas M.
   Contactame:
     Correos electr?nicos: juanesvm@rtks.site, esteban.villegas@utp.edu.co | Tel?fono: +57 300-1532237 | Sitio web: www.rtks.site
   Lenguaje C++, hecho en CLion 2024.5.1
*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream> //Librerias a usar
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <cstdlib>
#include <sstream>
using namespace std;

/////////////////////////////////////////////////////////////////////////////////////////////////////////

struct Fecha {  //Estructuras para guardar datos en los vetores
    int dia;
    int mes;
    int anio;
};

struct Gasto {
    string nombre;
    string tipo;
    long long valor;
    Fecha fecha;
    bool activo;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void limpiarPantalla() {
    system("cls");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void mostrarError(const string& mensaje) {
    cout << "Error: " << mensaje << endl;
    cout << "Presione Enter para continuar...";
    cin.ignore();
    cin.get();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

bool validarEntrada() {
    if (cin.fail()) {
        cin.clear();
        cin.ignore(1000000, '\n');
        return false;
    }
    return true;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void guardarGastos(const vector<Gasto*>& gastos) { //Guardar los gastos en el .txt
    ofstream archivo("gastos.txt");
    if (!archivo) {
        mostrarError("No se pudo abrir el archivo para guardar");
        return;
    }
    for (int i = 0; i < (int)gastos.size(); ++i) {
        archivo << gastos[i]->nombre << ","
                << gastos[i]->tipo << ","
                << gastos[i]->valor << ","
                << gastos[i]->fecha.dia << ","
                << gastos[i]->fecha.mes << ","
                << gastos[i]->fecha.anio << ","
                << gastos[i]->activo << "\n";
    }
    archivo.close();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void cargarGastos(vector<Gasto*>& gastos) { //Para cargar los gastos en el .txt
    ifstream archivo("gastos.txt");
    if (!archivo) {
        return;
    }
    string linea;
    while (getline(archivo, linea)) {
        Gasto* gasto = new Gasto();
        char nombre[100], tipo[100];
        int activo;
        sscanf(linea.c_str(), "%[^,],%[^,],%lld,%d,%d,%d,%d",
               nombre, tipo, &gasto->valor,
               &gasto->fecha.dia, &gasto->fecha.mes, &gasto->fecha.anio,
               &activo);
        gasto->nombre = nombre;
        gasto->tipo = tipo;
        gasto->activo = (activo != 0);
        gastos.push_back(gasto);
    }
    archivo.close();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void menu() {   //Menu principal del programa
    cout << "Bienvenido a MY FINANCE 3.0.1\n";
    cout << "Menu de opciones:\n";
    cout << "1. Agregar gastos\n";
    cout << "2. Modificar gastos\n";
    cout << "3. Eliminar gastos\n";
    cout << "4. Ver gastos\n";
    cout << "5. Ordenar gastos\n";
    cout << "6. Reporte de gastos\n";
    cout << "7. Salir\n";
    cout << "Seleccione una de las opciones: ";
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void agregarGasto(vector<Gasto*>& gastos) { //Para agregar un gasto
    Gasto* nuevoGasto = new Gasto;
    bool entradaValida = false;

    do {
        cout << "Ingrese el nombre del gasto: ";
        cin >> nuevoGasto->nombre;
        entradaValida = validarEntrada();
        if (!entradaValida) {
            mostrarError("Nombre no valido. Intente de nuevo."); //Valida si la entrada es correcta
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese el tipo de gasto: ";
        cin >> nuevoGasto->tipo;
        entradaValida = validarEntrada();
        if (!entradaValida) {
            mostrarError("Tipo no valido. Intente de nuevo.");
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese el valor del gasto: ";
        cin >> nuevoGasto->valor;
        entradaValida = validarEntrada();
        if (!entradaValida) {
            mostrarError("Valor no valido. Intente de nuevo.");
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese la fecha (dd mm aaaa): ";
        cin >> nuevoGasto->fecha.dia >> nuevoGasto->fecha.mes >> nuevoGasto->fecha.anio;
        entradaValida = validarEntrada() &&
                        nuevoGasto->fecha.dia > 0 && nuevoGasto->fecha.dia <= 31 &&
                        nuevoGasto->fecha.mes > 0 && nuevoGasto->fecha.mes <= 12 &&
                        nuevoGasto->fecha.anio >= 1900 && nuevoGasto->fecha.anio <= 2100;
        if (!entradaValida) {
            mostrarError("Fecha invalida. Intente de nuevo.");
        }
    } while (!entradaValida);

    nuevoGasto->activo = true;
    gastos.push_back(nuevoGasto);
    guardarGastos(gastos);
    cout << "Gasto agregado exitosamente.\n";
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void modificarGasto(vector<Gasto*>& gastos) { //Para modifica los gastos en el .txt
    int indice;
    bool entradaValida = false;

    do {
        cout << "Ingrese el indice del gasto a modificar: ";
        cin >> indice;
        entradaValida = validarEntrada() && indice >= 0 && indice < (int)gastos.size();
        if (!entradaValida) {
            mostrarError("Indice invalido. Intente de nuevo.");
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese el nuevo nombre del gasto: ";
        cin >> gastos[indice]->nombre;
        entradaValida = validarEntrada();
        if (!entradaValida) {
            mostrarError("Nombre no valido. Intente de nuevo.");
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese el nuevo tipo de gasto: ";
        cin >> gastos[indice]->tipo;
        entradaValida = validarEntrada();
        if (!entradaValida) {
            mostrarError("Tipo no valido. Intente de nuevo.");
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese el nuevo valor del gasto: ";
        cin >> gastos[indice]->valor;
        entradaValida = validarEntrada();
        if (!entradaValida) {
            mostrarError("Valor no valido. Intente de nuevo.");
        }
    } while (!entradaValida);

    do {
        cout << "Ingrese la nueva fecha (dd mm aaaa): ";
        cin >> gastos[indice]->fecha.dia >> gastos[indice]->fecha.mes >> gastos[indice]->fecha.anio;
        entradaValida = validarEntrada() &&
                        gastos[indice]->fecha.dia > 0 && gastos[indice]->fecha.dia <= 31 &&
                        gastos[indice]->fecha.mes > 0 && gastos[indice]->fecha.mes <= 12 &&
                        gastos[indice]->fecha.anio >= 1900 && gastos[indice]->fecha.anio <= 2100;
        if (!entradaValida) {
            mostrarError("Fecha invalida. Intente de nuevo.");
        }
    } while (!entradaValida);

    guardarGastos(gastos);
    cout << "Gasto modificado exitosamente.\n";
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void eliminarGasto(vector<Gasto*>& gastos) {  //Para eliminar los gastos en el .txt
    int indice;
    char tipo;
    cout << "Ingrese el indice del gasto a eliminar: ";
    cin >> indice;
    if (!validarEntrada() || indice < 0 || indice >= (int)gastos.size()) {
        mostrarError("Indice invalido");
        return;
    }

    cout << "Tipo de eliminacion (F para fisico, L para logico): ";
    cin >> tipo;
    if (!validarEntrada()) {
        mostrarError("Entrada no valida");
        return;
    }

    if (tipo == 'F' || tipo == 'f') {
        delete gastos[indice];
        gastos.erase(gastos.begin() + indice);
        cout << "Gasto eliminado fisicamente.\n";
    } else if (tipo == 'L' || tipo == 'l') {
        gastos[indice]->activo = false;
        cout << "Gasto eliminado logicamente.\n";
    } else {
        mostrarError("Tipo de eliminacion invalido");
        return;
    }
    guardarGastos(gastos);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void verGastos(const vector<Gasto*>& gastos) { //Para mostar los gastos en el .txt
    cout << "Los gastos son:\n";
    cout << "-------------------------------------------------------------\n";
    cout << "Nombre           | Tipo            | Valor      | Fecha\n";
    cout << "-------------------------------------------------------------\n";

    for (int i = 0; i < (int)gastos.size(); ++i) {
        if (gastos[i]->activo) {
            cout << gastos[i]->nombre;
            cout << string(17 - gastos[i]->nombre.length(), ' ') << "| ";

            cout << gastos[i]->tipo;
            cout << string(15 - gastos[i]->tipo.length(), ' ') << "| ";

            // Convertir valor a string
            ostringstream valorStream;
            valorStream << gastos[i]->valor;
            string valorStr = valorStream.str();

            cout << valorStr;
            cout << string(10 - valorStr.length(), ' ') << "| ";

            cout << (gastos[i]->fecha.dia < 10 ? "0" : "") << gastos[i]->fecha.dia << "/"
                 << (gastos[i]->fecha.mes < 10 ? "0" : "") << gastos[i]->fecha.mes << "/"
                 << gastos[i]->fecha.anio << "\n";
        }
    }
    cout << "-------------------------------------------------------------\n";
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////

bool compararGastos(const Gasto* a, const Gasto* b) { //Comparar fecha
    return a->fecha.anio < b->fecha.anio ||
           (a->fecha.anio == b->fecha.anio && a->fecha.mes < b->fecha.mes) ||
           (a->fecha.anio == b->fecha.anio && a->fecha.mes == b->fecha.mes && a->fecha.dia < b->fecha.dia);
}

void ordenarGastos(vector<Gasto*>& gastos) { // Para ordenar los gastos por fecha
    sort(gastos.begin(), gastos.end(), compararGastos);
    guardarGastos(gastos);
    cout << "Gastos ordenados por fecha.\n";
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void reporteGastos(const vector<Gasto*>& gastos) { //Para mostar el reporte de gastos, con total y promedio
    long long total = 0;
    int conteo = 0;

    cout << "Reporte de gastos." << endl;
    cout << "-------------------------------------------------------------\n";
    cout << "Nombre           | Tipo            | Valor      | Fecha\n";
    cout << "-------------------------------------------------------------\n";

    for (int i = 0; i < (int)gastos.size(); ++i) {
        if (gastos[i]->activo) {
            cout << gastos[i]->nombre;
            cout << string(17 - gastos[i]->nombre.length(), ' ') << "| ";

            cout << gastos[i]->tipo;
            cout << string(15 - gastos[i]->tipo.length(), ' ') << "| ";

            ostringstream valorStream; //Los valores a stream
            valorStream << gastos[i]->valor;
            string valorStr = valorStream.str();

            cout << valorStr;
            cout << string(10 - valorStr.length(), ' ') << "| ";

            cout << (gastos[i]->fecha.dia < 10 ? "0" : "") << gastos[i]->fecha.dia << "/"
                 << (gastos[i]->fecha.mes < 10 ? "0" : "") << gastos[i]->fecha.mes << "/"
                 << gastos[i]->fecha.anio << "\n";

            total += gastos[i]->valor;
            conteo++;
        }
    }

    cout << "-------------------------------------------------------------\n";
    cout << "Total de gastos: " << total << "\n";
    if (conteo > 0) {
        cout << "Promedio de gastos: " << (total / conteo) << "\n";
    } else {
        cout << "No hay gastos para calcular el promedio.\n";
    }
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////

int main() {
    vector<Gasto*> gastos;
    cargarGastos(gastos);
    int opcion;

    do {
        limpiarPantalla();
        menu();
        cin >> opcion;


        if (cin.fail() || opcion < 1 || opcion > 7) {
            cin.clear();
            cin.ignore(10000, '\n');
            mostrarError("Opcion no valida");
            continue;
        }

        limpiarPantalla();
        switch (opcion) {
            case 1: agregarGasto(gastos); break;
            case 2: modificarGasto(gastos); break;
            case 3: eliminarGasto(gastos); break;
            case 4: verGastos(gastos); break;
            case 5: ordenarGastos(gastos); break;
            case 6: reporteGastos(gastos); break;
            case 7: cout << "Saliendo del programa...\n"; break;
        }

        cout << " \n";
        cout << "Gracias por usar My-Finance APP.\n";
        cout << "Presione Enter para continuar...\n";
        cout << "-------------------------------------------------------------\n";
        cin.ignore();
        cin.get();

    } while (opcion != 7);

    for (int i = 0; i < (int)gastos.size(); ++i) {
        delete gastos[i];
    }
    return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
 Notas de versi?n:
  Utiliza 11 funciones de tipo void, una para cada submen? en el men? de opciones.
  En esta versi?n, se a?ade la validaci?n de datos para que, si se realiza una entrada no v?lida, permita su correcci?n.
  Los gastos se muestran en formato de tabla.
  Los gastos se organizan utilizando el m?todo de ordenaci?n, por fecha de mayor a mayor reciente.
  Al final de cualquier acci?n, se le pide que presione enter para salir.
  La limpieza de la pantalla se realiza para cada opci?n.
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////
